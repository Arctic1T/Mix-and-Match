
## Spanish visibility reproduction

The live Spanish page contains the translated large headings in extracted content, including `Una razón fresca para sonreír`, `Elige tu mezcla perfecta`, `Un scroll lleno de cosas buenas`, and `Tu próxima pausa feliz`. However, after scrolling to the story section, the large story heading and body render extremely pale against the white background. This indicates a visibility/entrance-animation state issue rather than a missing Spanish string. The hero Spanish title remains visible.

## Post-fix menu validation

After changing section content to start opaque and limiting initial opacity to the welcome/hero layers, the Spanish menu heading `Elige tu mezcla perfecta` renders fully dark and readable immediately on scroll. Existing menu cards remain visible and the new gallery labels are present in the DOM.

## Spanish gallery validation

The gallery heading `Un scroll lleno de cosas buenas` is rendered dark and readable. The existing gallery mosaic remains stable on desktop, and the three new bilingual labels are present: `Momento de smoothie rosado`, `Smoothie verde en el café`, and `Waffles de fresa y banano`. The added photos are included in the gallery data and modal flow.

## Spanish visit and footer validation

At the end of the Spanish page, `Tu próxima pausa feliz` is fully dark and readable. The pickup callout displays the Spanish copy and `BLANK` phone placeholder. The footer shows the supplied logo, Spanish brand line, hours/location, Google review link, and back-to-top action without missing text.

## Spanish modal-test setup

After a fresh load, Spanish mode switched correctly and the gallery navigation button brought the page to the gallery section. The translated gallery heading and current gallery cards render correctly; the newly added items remain represented by their translated labels in the full-page content.

## Spanish gallery modal validation

The newly added pink smoothie card opens a modal successfully in Spanish. The modal displays the new image, the translated label `Momento de smoothie rosado`, and a visible close control with the accessibility hint `Cerrar imagen`.
