# Mix and Match responsive QA findings

The direct interior routes `/?lang=en` and `/?lang=es` were captured at 375×812 in full-page mobile mode after the Spanish visibility fix and gallery expansion.

Both languages show readable hero titles, story headings, menu headings and cards, gallery heading and all gallery rows including the three newly added photos, the visit heading/card with pickup text, and the logo footer. The Spanish accents and line breaks remain visible at mobile width. The new query parameter is only a QA/deep-link convenience; the normal site still opens with the language-choice welcome screen when no `lang` parameter is present.

The Spanish gallery modal was also opened with the new pink smoothie item and showed its translated label plus the `Cerrar imagen` accessibility hint.
